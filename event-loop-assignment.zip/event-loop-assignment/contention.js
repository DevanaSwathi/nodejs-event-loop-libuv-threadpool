// Experiment 4: slow pool tasks delay an unrelated small fs read
const crypto = require('crypto');
const fs = require('fs');

const start = Date.now();

for (let i = 0; i < 4; i++) {
  crypto.pbkdf2('pw', 'salt', 500000, 64, 'sha512', () => {
    console.log(`hash ${i + 1} done at ${Date.now() - start} ms`);
  });
}

fs.readFile(__filename, () => {
  console.log(`fs.readFile took ${Date.now() - start} ms`);
});
