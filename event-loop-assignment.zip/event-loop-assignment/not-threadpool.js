// Experiment 3: CPU-bound JavaScript blocks the main thread; the pool does not help
const http = require('http');

function fib(n) { return n < 2 ? n : fib(n - 1) + fib(n - 2); }

http.createServer((req, res) => {
  if (req.url === '/block') {
    res.end(String(fib(42)));   // heavy sync work on the main thread
  } else {
    res.end('fast');
  }
}).listen(3000, () => console.log('Server on http://localhost:3000  (try /block then /)'));
