// Experiment 2: thread pool size vs parallelism
const crypto = require('crypto');
const os = require('os');

const CALLS = Number(process.env.CALLS || 8);
console.log(`CPU cores: ${os.cpus().length}, UV_THREADPOOL_SIZE: ${process.env.UV_THREADPOOL_SIZE || '4 (default)'}, tasks: ${CALLS}`);

const start = Date.now();
for (let i = 1; i <= CALLS; i++) {
  crypto.pbkdf2('password', 'salt', 500000, 64, 'sha512', () => {
    console.log(`Task ${i} finished at ${Date.now() - start} ms`);
  });
}
