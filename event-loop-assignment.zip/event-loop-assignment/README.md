# Node.js Event Loop and libuv Thread Pool

Experiments showing how UV_THREADPOOL_SIZE affects Node.js performance.

## Setup
    npm install

## Run
    npm run order          # event loop order
    npm run pool:1         # thread pool size 1
    npm run pool:4         # default size
    npm run pool:8
    npm run pool:16
    npm run block          # then open /block and / in two browser tabs
    npm run contention:4   # fs read delayed by hashing
    npm run contention:8   # fs read fast

## Files
- order.js: nextTick, promises, timers, setImmediate order
- threadpool.js: 8 pbkdf2 tasks, timing per pool size
- not-threadpool.js: CPU-bound JS blocks the event loop
- contention.js: small fs read waiting behind slow crypto tasks
