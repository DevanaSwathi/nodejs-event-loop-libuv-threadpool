// Experiment 1: event loop execution order
const fs = require('fs');

console.log('1. sync start');

setTimeout(() => console.log('6. setTimeout 0'), 0);
setImmediate(() => console.log('7. setImmediate'));
process.nextTick(() => console.log('3. nextTick'));
Promise.resolve().then(() => console.log('4. promise microtask'));

fs.readFile(__filename, () => {
  console.log('5. fs.readFile callback (thread pool)');
  setTimeout(() => console.log('9. timeout inside I/O'), 0);
  setImmediate(() => console.log('8. immediate inside I/O'));
});

console.log('2. sync end');
